TERMS AND CONDITIONS
Please take a moment to review the Legal Terms and Conditions of this resource pack.
By downloading this texture pack you agree to these terms and conditions.
YOU MAY:
	Take screenshots and post the screenshots online but you must give credit to Copernicle.
	Create videos and upload the video to websites as long as a link to this resource pack and proper credit to Copernicle is given.
	Stream with this pack but you must put the link to this resource pack and proper credit to Copernicle is given.

YOU MAY NOT:
	Re-Distribute or Re-Upload this resource pack or part of this resource pack, including other platforms.
    	Put a texture belonging to this pack into another Resource pack, file, or image.
	Claim this as your own.

Thank you for using this resource pack by Copernicle.
Copyright © by Copernicle 2021

